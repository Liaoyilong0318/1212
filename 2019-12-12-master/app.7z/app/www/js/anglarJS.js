angular
.module('App', [])
.controller('LoginConController', ['$scope', function($scope){
    $scope.done = '';
}])

.directive('loadingBtn', ['$timeout', function($timeout){
    return {
        link: function(scope, element, attrs){
            element.bind('click', function(){
                if(scope.loading == true || scope.done == 'done'){
                    return;
                }
                scope.loading = true;
                element.addClass('loading');
                timeoutId = $timeout(function () {
                    scope.loading = false;
                    element.removeClass('loading');
                    scope.done = 'done';
                }, 2000);               
            });
        }
    };
}]);

function onLoad(){
    document.addEventListener("deviceready", onDeviceReady, false);
    if(localStorage.userName != null){
        document.getElementById("user").value = localStorage.userName;
    }
    if(localStorage.userPassword != null){
        document.getElementById("passwd").value = localStorage.userPassword;
    }
    }

    function onDeviceReady(){
        navigator.geolocation.getCurrentPosition(onSuccess, onErrot, {
            timeout: 30000
        });
    }
    // function onDeviceReady(){
    //     alert("onDeviceReady");
    //     getPosition();
    // }
    // function getPosition(){
    //     var options = {
    //         enableHighAccuracy: true,
    //         maximumAge: 3600000
    //     }
    //     var watchID = navigator.geolocation.getCurrentPosition(onSuccess,onErrot,options);
    //     function onSuccess(position){
    //         localStorage.lon=position.coords.longitude;
    //         localStorage.lon=position.coords.latitude;
    //     };
    //     function onErrot(position){
    //         alert('code:'+err.code + "\n"+
    //               'message:' + error.message + '\n');
    //     }
    // }

    function noteOnLoad(){
        var id=localStorage.userName;
        $.ajax({
            datatype:"JSON",
            type:"POST",
            url:"http://210.70.80.21/~s107021008/getNotes.php?",
            data:"userEmail="+id,
            crossDomain:true,
            cache:false,
            success: function(data){
                var obj = JSON.parse(data);
                $("#div3").html('');
                var div3Content='';
                for(var i=0;i<obj.length;i++){
                    div3Content+='<p>'+obj[i].type+','+obj[i].title+'</p>';
                }
                $("#div3").append(div3Content);
            },
            error:function(data){
                alert("Error:"+data);
            }
    
        }
        )
    }
    

function login(){
    var id= document.getElementById("user").value;
    var passwd = document.getElementById("passwd").value;
    $.ajax({
        datatype: "JSON",
        type: "POST",
        url:"http://210.70.80.21/~s107021151/login.php?",
        data:"userName="+id+"&userPassword="+passwd,
        crossDomain: true,
        cache: false,
        success: function(data){
            
            var obj = JSON.parse(data);
            if( obj.status =="success"){
                localStorage.userName=id;
                localStorage.userPassword=passwd;
                localStorage.loginType=0;
                document.location.href="MainPage.html";
            }else if(obj.status == "noAccount"){
                alert("Wrong ID or Password!!");
            }else if(obj.status == "fail"){
                alert("Can't connect to DB");
            }
        },
        error: function(data){
            alert("Error: " + data);
        }
    });
}
